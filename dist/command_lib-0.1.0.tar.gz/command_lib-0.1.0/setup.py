# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['command_lib',
 'command_lib.dataset_io',
 'command_lib.factory',
 'command_lib.parser',
 'command_lib.run_command',
 'command_lib.utils']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML==5.4.1',
 'SQLAlchemy==1.4.41',
 'mysql-connector-python>=8.0.31,<9.0.0',
 'numpy==1.21.6',
 'pandas==1.3.5']

setup_kwargs = {
    'name': 'command-lib',
    'version': '0.1.0',
    'description': 'command line utility to run named sql commands',
    'long_description': None,
    'author': 'RahulP',
    'author_email': 'rahul8.paul@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<3.11',
}


setup(**setup_kwargs)
